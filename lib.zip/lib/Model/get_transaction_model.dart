/// error : false
/// message : "Transactions Retrieved Successfully"
/// total : "110"
/// data : [{"id":"2820","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"204","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 2058","transaction_date":"2022-11-17 14:43:25","date_created":"2022-11-17 14:43:25","t_date":"0000-00-00"},{"id":"2799","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"85","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 2033","transaction_date":"2022-11-15 22:11:46","date_created":"2022-11-15 22:11:46","t_date":"0000-00-00"},{"id":"2768","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"85","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1999","transaction_date":"2022-11-12 21:39:50","date_created":"2022-11-12 21:39:50","t_date":"0000-00-00"},{"id":"2765","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"110.5","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1994","transaction_date":"2022-11-12 21:39:50","date_created":"2022-11-12 21:39:50","t_date":"0000-00-00"},{"id":"2726","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"204","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1952","transaction_date":"2022-11-10 22:14:27","date_created":"2022-11-10 22:14:27","t_date":"0000-00-00"},{"id":"2723","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"85","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1948","transaction_date":"2022-11-10 22:14:27","date_created":"2022-11-10 22:14:27","t_date":"0000-00-00"},{"id":"2722","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"59.5","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1947","transaction_date":"2022-11-10 22:14:27","date_created":"2022-11-10 22:14:27","t_date":"0000-00-00"},{"id":"2704","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"187","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1929","transaction_date":"2022-11-09 21:37:55","date_created":"2022-11-09 21:37:55","t_date":"0000-00-00"},{"id":"2686","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"136","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1909","transaction_date":"2022-11-08 21:38:28","date_created":"2022-11-08 21:38:28","t_date":"0000-00-00"},{"id":"2670","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"187","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1893","transaction_date":"2022-11-06 22:00:09","date_created":"2022-11-06 22:00:09","t_date":"0000-00-00"},{"id":"2626","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"110.5","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1841","transaction_date":"2022-11-03 09:02:28","date_created":"2022-11-03 09:02:28","t_date":"0000-00-00"},{"id":"2625","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"35.7","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1840","transaction_date":"2022-11-03 09:02:28","date_created":"2022-11-03 09:02:28","t_date":"0000-00-00"},{"id":"2473","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"187","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1744","transaction_date":"2022-10-23 22:29:18","date_created":"2022-10-23 22:29:18","t_date":"0000-00-00"},{"id":"2409","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"212.5","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1704","transaction_date":"2022-10-19 22:01:48","date_created":"2022-10-19 22:01:48","t_date":"0000-00-00"},{"id":"2408","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"29.75","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1703","transaction_date":"2022-10-19 22:01:48","date_created":"2022-10-19 22:01:48","t_date":"0000-00-00"},{"id":"2321","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"136","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1638","transaction_date":"2022-10-16 22:01:46","date_created":"2022-10-16 22:01:46","t_date":"0000-00-00"},{"id":"2226","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"340","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1576","transaction_date":"2022-10-12 23:03:17","date_created":"2022-10-12 23:03:17","t_date":"0000-00-00"},{"id":"2225","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"374","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1575","transaction_date":"2022-10-12 23:03:17","date_created":"2022-10-12 23:03:17","t_date":"0000-00-00"},{"id":"2224","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"204","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1574","transaction_date":"2022-10-12 23:03:17","date_created":"2022-10-12 23:03:17","t_date":"0000-00-00"},{"id":"2223","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"374","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1573","transaction_date":"2022-10-12 23:03:17","date_created":"2022-10-12 23:03:17","t_date":"0000-00-00"},{"id":"2210","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"204","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1558","transaction_date":"2022-10-12 23:03:17","date_created":"2022-10-12 23:03:17","t_date":"0000-00-00"},{"id":"2209","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"136","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1557","transaction_date":"2022-10-12 23:03:17","date_created":"2022-10-12 23:03:17","t_date":"0000-00-00"},{"id":"2174","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"85","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1548","transaction_date":"2022-10-11 22:01:34","date_created":"2022-10-11 22:01:34","t_date":"0000-00-00"},{"id":"2169","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"136","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1542","transaction_date":"2022-10-11 22:01:34","date_created":"2022-10-11 22:01:34","t_date":"0000-00-00"},{"id":"2168","transaction_type":"wallet","user_id":"167","order_id":null,"type":"credit","txn_id":null,"payu_txn_id":null,"amount":"170","status":null,"currency_code":null,"payer_email":null,"message":"Commission Amount Credited for Order Item ID  : 1541","transaction_date":"2022-10-11 22:01:34","date_created":"2022-10-11 22:01:34","t_date":"0000-00-00"}]

class GetTransactionModel {
  GetTransactionModel({
    bool? error,
    String? message,
    String? total,
    List<Data>? data,
  }) {
    _error = error;
    _message = message;
    _total = total;
    _data = data;
  }

  GetTransactionModel.fromJson(dynamic json) {
    _error = json['error'];
    _message = json['message'];
    _total = json['total'];
    if (json['data'] != null) {
      _data = [];
      json['data'].forEach((v) {
        _data?.add(Data.fromJson(v));
      });
    }
  }
  bool? _error;
  String? _message;
  String? _total;
  List<Data>? _data;
  GetTransactionModel copyWith({
    bool? error,
    String? message,
    String? total,
    List<Data>? data,
  }) =>
      GetTransactionModel(
        error: error ?? _error,
        message: message ?? _message,
        total: total ?? _total,
        data: data ?? _data,
      );
  bool? get error => _error;
  String? get message => _message;
  String? get total => _total;
  List<Data>? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['error'] = _error;
    map['message'] = _message;
    map['total'] = _total;
    if (_data != null) {
      map['data'] = _data?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : "2820"
/// transaction_type : "wallet"
/// user_id : "167"
/// order_id : null
/// type : "credit"
/// txn_id : null
/// payu_txn_id : null
/// amount : "204"
/// status : null
/// currency_code : null
/// payer_email : null
/// message : "Commission Amount Credited for Order Item ID  : 2058"
/// transaction_date : "2022-11-17 14:43:25"
/// date_created : "2022-11-17 14:43:25"
/// t_date : "0000-00-00"

class Data {
  Data({
    String? id,
    String? transactionType,
    String? userId,
    dynamic orderId,
    String? admin_com,
    String? type,
    dynamic txnId,
    dynamic payuTxnId,
    String? amount,
    dynamic status,
    dynamic currencyCode,
    dynamic payerEmail,
    String? message,
    String? transactionDate,
    String? dateCreated,
    String? tDate,
  }) {
    _id = id;
    _transactionType = transactionType;
    _userId = userId;
    _orderId = orderId;
    _type = type;
    _txnId = txnId;
    _admin_com = admin_com;
    _payuTxnId = payuTxnId;
    _amount = amount;
    _status = status;
    _currencyCode = currencyCode;
    _payerEmail = payerEmail;
    _message = message;
    _transactionDate = transactionDate;
    _dateCreated = dateCreated;
    _tDate = tDate;
  }

  Data.fromJson(dynamic json) {
    _id = json['id'];
    _transactionType = json['transaction_type'];
    _userId = json['user_id'];
    _orderId = json['order_id'];
    _type = json['type'];
    _admin_com = json['admin_com'];
    _txnId = json['txn_id'];
    _payuTxnId = json['payu_txn_id'];
    _amount = json['amount'];
    _status = json['status'];
    _currencyCode = json['currency_code'];
    _payerEmail = json['payer_email'];
    _message = json['message'];
    _transactionDate = json['transaction_date'];
    _dateCreated = json['date_created'];
    _tDate = json['t_date'];
  }
  String? _id;
  String? _transactionType;
  String? _userId;
  dynamic _orderId;
  String? _type;
  dynamic _txnId;
  dynamic _payuTxnId;
  String? _admin_com;
  String? _amount;
  dynamic _status;
  dynamic _currencyCode;
  dynamic _payerEmail;
  String? _message;
  String? _transactionDate;
  String? _dateCreated;
  String? _tDate;
  Data copyWith({
    String? id,
    String? transactionType,
    String? userId,
    dynamic orderId,
    String? type,
    dynamic txnId,
    dynamic payuTxnId,
    String? amount,
    dynamic status,
    dynamic currencyCode,
    dynamic payerEmail,
    String? message,
    String? transactionDate,
    String? dateCreated,
    String? tDate,
  }) =>
      Data(
        id: id ?? _id,
        transactionType: transactionType ?? _transactionType,
        userId: userId ?? _userId,
        orderId: orderId ?? _orderId,
        type: type ?? _type,
        txnId: txnId ?? _txnId,
        payuTxnId: payuTxnId ?? _payuTxnId,
        amount: amount ?? _amount,
        status: status ?? _status,
        currencyCode: currencyCode ?? _currencyCode,
        admin_com: admin_com ?? _admin_com,
        payerEmail: payerEmail ?? _payerEmail,
        message: message ?? _message,
        transactionDate: transactionDate ?? _transactionDate,
        dateCreated: dateCreated ?? _dateCreated,
        tDate: tDate ?? _tDate,
      );
  String? get id => _id;
  String? get transactionType => _transactionType;
  String? get userId => _userId;
  dynamic get orderId => _orderId;
  String? get type => _type;
  dynamic get txnId => _txnId;
  dynamic get payuTxnId => _payuTxnId;
  String? get amount => _amount;
  String? get admin_com => _admin_com;
  dynamic get status => _status;
  dynamic get currencyCode => _currencyCode;
  dynamic get payerEmail => _payerEmail;
  String? get message => _message;
  String? get transactionDate => _transactionDate;
  String? get dateCreated => _dateCreated;
  String? get tDate => _tDate;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['transaction_type'] = _transactionType;
    map['user_id'] = _userId;
    map['order_id'] = _orderId;
    map['type'] = _type;
    map['txn_id'] = _txnId;
    map['payu_txn_id'] = _payuTxnId;
    map['amount'] = _amount;
    map['status'] = _status;
    map['currency_code'] = _currencyCode;
    map['payer_email'] = _payerEmail;
    map['admin_com'] = _admin_com;
    map['message'] = _message;
    map['transaction_date'] = _transactionDate;
    map['date_created'] = _dateCreated;
    map['t_date'] = _tDate;
    return map;
  }
}
