class Myassets {
  static const String app_logo = 'assets/logo/food_on_the_way.png';
  static const String login_logo = 'assets/logo/login_logo.png';
  static const String loding_logo = 'assets/logo/loding_product.png';
  static const String loding_logobg = 'assets/logo/loging_bg.png';
}
