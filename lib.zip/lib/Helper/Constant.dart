final String appName = 'Eatoz Restaurant';

final String packageName = 'com.eatozfood.seller';

final String iosPackage = 'com.eatozfood.seller';
// https://alphawizztest.tk/Food_on_the_way/app/v1/api/
// final String baseUrl = 'https://foodontheways.com/seller/app/v1/api/';
//final String baseUrl = 'https://foodontheways.com/New_food/seller/app/v1/api/';
// /*final String baseUrl = 'https://eatoz.in/seller/app/v1/api/';*/
final String baseUrl = 'https://eatoz.in/seller/app/v1/api/';
// final String baseUrl = 'https://developmentalphawizz.com/eatoz/seller/app/v1/api/';
final String jwtKey = "f78d95e500c7ef84ee99d69d9651ff7a229979a2";

//timeout limit
final int timeOut = 50;
const int perPage = 10;

const String BANK_DETAIL = 'Bank Details:\n' +
    'Account No :123XXXXX\n' +
    'IFSC Code: 123XXX \n' +
    'Name: Abc xyz';
